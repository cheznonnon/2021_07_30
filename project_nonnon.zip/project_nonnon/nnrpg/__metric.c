// Nekomimi Nina RPG
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "../nonnon/game/game.c"

#include "../nonnon/win32/gdi.c"
#include "../nonnon/project/macro.c"




typedef struct {


	// Zoom

	s32 zoom;
	s32 scale;
	s32 csx, csy;
	s32 frame_size;


	// Unit

	s32 unit_bmp;
	s32 unit_pad;


	// Color

	u32 color_trans;

	u32 color_window_1;
	u32 color_window_2;


	// Position and Size

	s32 command_x, command_y, command_sx, command_sy;
	s32 mainwin_x, mainwin_y, mainwin_sx, mainwin_sy;
	s32 chara_0_x, chara_0_y;
	s32 chara_1_x, chara_1_y;
	s32 chara_2_x, chara_2_y;


	// Font

	n_posix_char *font;
	s32           textsize;


	// Target Canvas

	n_bmp *bg;
	n_bmp *canvas;


} n_nnrpg_metric_struct;


static n_nnrpg_metric_struct n_nnrpg_metric;




void
n_nnrpg_metric_make( n_bmp *bmp_bg, n_bmp *bmp_canvas )
{

	// Zoom : 1/2/4 only supported

	s32 desktop_sx; n_win_desktop_size( &desktop_sx, NULL );

	n_nnrpg_metric.zoom = n_posix_max( 1, desktop_sx / 640 );

	{

		n_posix_char *cmdline = n_win_commandline_new();

		n_string_commandline_option_literal( "-nnrpg", cmdline );

		if ( n_posix_atoi( cmdline ) )
		{
			n_nnrpg_metric.zoom = n_posix_max( 1, n_posix_atoi( cmdline ) );
		}

		n_string_free( cmdline );

	}

	if ( n_nnrpg_metric.zoom > 2 ) { n_nnrpg_metric.zoom = n_nnrpg_metric.zoom / 2 * 2; }

	n_nnrpg_metric.csx = 320 * n_nnrpg_metric.zoom;
	n_nnrpg_metric.csy = 240 * n_nnrpg_metric.zoom;

	n_nnrpg_metric.scale = n_nnrpg_metric.zoom / 2;


	// Color

	n_nnrpg_metric.color_trans    = n_bmp_white_invisible;

	n_nnrpg_metric.color_window_1 = n_bmp_argb( 128,  0,100,150 );
	n_nnrpg_metric.color_window_2 = n_bmp_argb( 128,  0,  0, 50 );


	// Position and Size

	s32 unit_sx = ( n_nnrpg_metric.csx / 4 );
	s32 unit_sy = ( n_nnrpg_metric.csy / 3 );
	s32 main_sy = n_nnrpg_metric.csy - unit_sy;


	n_nnrpg_metric.font       = n_project_stdfont();//n_posix_literal( "Arial" );//

	if ( n_nnrpg_metric.zoom == 4 )
	{
		n_nnrpg_metric.textsize   = 15 * n_nnrpg_metric.zoom;
	} else {
		n_nnrpg_metric.textsize   = 16 * n_nnrpg_metric.zoom;
	}

	if ( n_string_is_same_literal( "Arial", n_nnrpg_metric.font ) )
	{
		n_nnrpg_metric.textsize = (double) n_nnrpg_metric.textsize * 0.8;
	}

	n_nnrpg_metric.frame_size = n_nnrpg_metric.textsize / 3;


	n_nnrpg_metric.command_x  = 0;
	n_nnrpg_metric.command_y  = unit_sy * 2;
	n_nnrpg_metric.command_sx = unit_sx * 1;
	n_nnrpg_metric.command_sy = unit_sy * 1;
	n_nnrpg_metric.mainwin_x  = n_nnrpg_metric.command_sx;
	n_nnrpg_metric.mainwin_y  = n_nnrpg_metric.command_y;
	n_nnrpg_metric.mainwin_sx = unit_sx * 3;
	n_nnrpg_metric.mainwin_sy = unit_sy * 1;


	n_nnrpg_metric.unit_bmp   = 64 * n_nnrpg_metric.zoom;
	n_nnrpg_metric.unit_pad   =  4 * n_nnrpg_metric.zoom;

	n_nnrpg_metric.chara_0_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, n_nnrpg_metric.unit_bmp / 2 );
	n_nnrpg_metric.chara_1_x  = ( unit_sx * 3 ) + n_game_centering( unit_sx * 1, n_nnrpg_metric.unit_bmp / 2 );
	n_nnrpg_metric.chara_2_x  = ( unit_sx * 0 ) + n_game_centering( unit_sx * 3, n_nnrpg_metric.unit_bmp / 1 );

	n_nnrpg_metric.chara_0_y  = ( main_sy / 2 ) - n_nnrpg_metric.unit_bmp;
	n_nnrpg_metric.chara_1_y  = ( main_sy / 2 );
	n_nnrpg_metric.chara_2_y  = n_game_centering( main_sy / 1, n_nnrpg_metric.unit_bmp );


	// Target Canvas

	n_nnrpg_metric.bg     = bmp_bg;
	n_nnrpg_metric.canvas = bmp_canvas;


	return;
}

