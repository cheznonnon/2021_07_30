// Nonnon Win32
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#ifndef _H_NONNON_WIN32_GDI_ICON
#define _H_NONNON_WIN32_GDI_ICON




#include "../sysinfo/drive.c"
#include "../sysinfo/version.c"




// internal
void
n_gdi_icon_hicon2bmp( HICON hicon, n_bmp *bmp, n_bmp *msk )
{

	// [!] : WinVista or later : these parameters are changed by DPI

	s32 ico_sx, ico_sy; n_win_stdsize_icon_large( &ico_sx, &ico_sy );

	n_win_icon_hicon2bmp_1st( hicon, ico_sx,ico_sy, bmp, msk );

	// [x] : buggy : Win9x/NT4.0 have alpha garbage icons

	if ( n_posix_false == n_sysinfo_version_2000_or_later() )
	{
		n_bmp_alpha_visible( bmp );
	}

	n_curico_mask_restore( bmp, msk );

//n_bmp_save_literal( bmp, "bmp.bmp" );
//n_bmp_save_literal( msk, "msk.bmp" );


	return;
}

n_posix_bool
n_gdi_icon_ext_is_bmp( const n_posix_char *pth )
{

	if ( n_string_is_empty( pth ) ) { return n_posix_false; }


	const n_posix_char *ext     = n_posix_literal( ".bmp" );
	const int           ext_cch = 4;


	s64 f_cch = ext_cch;
	s64 t_cch = n_posix_strlen( pth );

	if ( t_cch ==     0 ) { return n_posix_false; }
	if ( f_cch >= t_cch ) { return n_posix_false; }


	const int offset = n_posix_literal( 'a' ) - n_posix_literal( 'A' );


	int match = 0;
	int f     = f_cch;
	int t     = t_cch;
	while( 1 )
	{

		if ( f == 0 ) { break; }
		if ( t == 0 ) { break; }

		f--;
		t--;

		int char_f = ext[ f ];
		int char_t = pth[ t ];

		if ( n_string_char_is_upper( char_f ) ) { char_f += offset; }
		if ( n_string_char_is_upper( char_t ) ) { char_t += offset; }

		if ( char_f == char_t )
		{
			match++;
		} else {
			break;
		}

	}


	n_posix_bool ret = n_posix_false;

	if ( match == f_cch )
	{
//n_posix_debug_literal( " %s ", &pth[ t ] );

		if (
			( t == ext_cch )
			||
			( ( t >= 1 )&&( pth[ t - 1 ] == N_POSIX_CHAR_SLASH ) )
		)
		{
			// [!] : avoid dot files
		} else {
			ret = n_posix_true;
		}
	}


	return ret;
}

void
n_gdi_icon_extract( n_bmp *bmp, n_posix_char *icon_name, int icon_index )
{
//return;

	if ( bmp == NULL ) { return; }

	if ( n_string_is_empty( icon_name ) ) { return; }


	// [!] : OFF for performance

	//if ( icon_index >= n_win_icon_maxcount( icon_name ) ) { return; }


	// [x] : ExtractAssociatedIcon()
	//
	//	crash in recyclebin
	//
	//	when access to $RECYCLE.BIN with XP or earlier version
	//
	//	FAT            : RECYCLED
	//	NTFS           : RECYCLER/{ user id }/
	//	Vista or later : $RECYCLE.BIN/{ user id }/
	//
	//	this module cannot handle this for performance


	// [x] : error dialog will appear
	//
	//	ExtractIcon(), ExtractIconEx(), ExtractAssociatedIcon()
	//	GetDiskFreeSpaceEx()
	//
	//	a : when removable drives
	//	b : when optical drives and a disk is ejected


	if ( n_sysinfo_drive_is_empty( icon_name ) )
	{

		u32 type = n_sysinfo_drive_type( icon_name );

		if ( type == DRIVE_REMOVABLE ) { icon_index =  7; } else
		if ( type == DRIVE_CDROM     ) { icon_index = 11; } else { icon_index = 8; }

		icon_name = n_posix_literal( "shell32.dll" );

	} else {

		// [x] : ExtractAssociatedIcon()
		//
		//	crash when the target file is not exist

		// [!] : Win9x : icon_name = " " will be n_posix_true : its reason is unknown

		if ( n_posix_false == n_posix_stat_is_exist( icon_name ) )
		{
			if ( n_posix_false == n_string_is_same_literal( "shell32.dll", icon_name ) ) { return; }
		}


		// [!] : when .BMP
		//
		//	0 : bitmap itself
		//	1 : associated icon

		if ( n_gdi_icon_ext_is_bmp( icon_name ) ) { icon_index = 1; }

	}


	HICON hicon = n_win_icon_ExtractAssociatedIcon( icon_name, icon_index );
	if ( hicon == NULL ) { return; }

	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );

	n_gdi_icon_hicon2bmp( hicon, &b, &m ); 

	n_win_icon_exit( hicon );


//n_bmp_save_literal( &m, "mask.bmp" );

//n_bmp_flush( &b, n_bmp_rgb( 0,200,255 ) );


	n_bmp_free_fast( bmp );
	n_bmp_alias( &b, bmp );

	n_bmp_free_fast( &m );

//n_bmp_save_literal( bmp, "debug.bmp" );


	return;
}

n_posix_bool
n_gdi_icon_resource_load( n_gdi *gdi, n_bmp *icon, n_posix_bool *is_lnk, n_posix_bool *resize_needed )
{
//return n_posix_true;

	int option = N_WIN_ICON_INIT_OPTION_RESOURCE;
	if ( gdi->icon_style & N_GDI_ICON_RC_RESOLVE )
	{
		option |= N_WIN_ICON_INIT_OPTION_NAME_RESOLVE;
	}


	n_bmp b; n_bmp_zero( &b );
	n_bmp m; n_bmp_zero( &m );

	n_posix_bool ret = n_posix_true;
	n_win_icon_init_internal
	(
		gdi->icon,
		gdi->icon_index,
		gdi->icon_bpp,
		gdi->icon_rsrc,
		&b, &m,
		&gdi->icon_loaded_bpp,
		&gdi->icon_loaded_size,
		gdi->icon_color_bg,
		n_posix_true,
		8,
		n_posix_false,
		is_lnk,
		resize_needed,
		&ret,
		option
	);
/*
n_posix_char *name = n_string_path_name_new( gdi->icon );
n_posix_char str[ 1024 ]; n_posix_sprintf_literal( str, "./_empty/%s.bmp", name );
if ( n_posix_false == n_posix_stat_is_exist( str ) )
{
	n_bmp_save( &b, str );
} else {
	n_posix_sprintf_literal( str, "./_empty/%s (2).bmp", name );
	n_bmp_save( &b, str );
}
n_string_path_free( name );
*/

	if ( (*resize_needed) )
	{
		// [x] : multi-thread unsafe
		//n_gdi_icon_hicon2bmp( NULL, &b, &m );

		n_curico_mask_restore( &b, &m );
	}


	n_bmp_free_fast( icon );
	n_bmp_alias( &b, icon );

	n_bmp_free_fast( &m );


//n_bmp_save_literal( icon, "ret.bmp" );


	return ret;
}

n_posix_bool
n_gdi_icon_picture_load( const n_gdi *gdi, n_bmp *icon )
{

	if (
		( n_bmp_load   ( icon, gdi->icon ) )
#ifdef _H_NONNON_NEUTRAL_PNG
		&&
		( n_png_png2bmp( gdi->icon, icon ) )
#endif // #ifdef _H_NONNON_NEUTRAL_PNG
#ifdef _H_NONNON_NEUTRAL_JPG
		&&
		( n_jpg_jpg2bmp( gdi->icon, icon ) )
#endif // #ifdef _H_NONNON_NEUTRAL_JPG
	)
	{
		return n_posix_true;
	} else {
		//return n_posix_false;
	}
//n_bmp_save_literal( icon, "0.bmp" );


	return n_posix_false;
}

void
n_gdi_icon_draw( n_gdi *gdi, n_bmp *bmp )
{

	if ( gdi == NULL ) { return; }

	if ( n_string_is_same( N_GDI_ICON_NAME_EMPTY, gdi->icon ) ) { return; }


	if ( n_bmp_error( bmp ) ) { return; }


	n_posix_bool is_lnk = n_posix_false;


	n_bmp icon; n_bmp_zero( &icon );


	{

		n_posix_bool is_error = n_posix_false;
		n_posix_bool is_image = n_posix_false;

		if ( n_posix_false == ( gdi->icon_style & N_GDI_ICON_IMAGELOADER ) )
		{

			is_error = n_posix_true;

		} else
		if (
			( n_string_path_is_drivename( gdi->icon ) )
			||
			(
				( n_gdi_icon_picture_load( gdi, &icon ) )
#ifdef _H_NONNON_WIN32_OLE_IPICTURE
				&&
				( n_IPicture_load_shrink( gdi->icon, &icon, gdi->icon_sx * 2, gdi->icon_sy * 2 ) )
#endif // #ifdef _H_NONNON_WIN32_OLE_IPICTURE
			)
		)
		{
//n_bmp_new( &icon, 32,32 );
//n_posix_debug_literal( " 1 " );

			is_error = n_posix_true;

		} else {

			is_image = n_posix_true;

		}

		n_posix_bool resize_needed = n_posix_true;

		if ( is_error )
		{
			if ( gdi->icon_style & N_GDI_ICON_RESOURCE )
			{
				is_error = n_gdi_icon_resource_load( gdi, &icon, &is_lnk, &resize_needed );
//if ( is_error == n_posix_false ) { n_posix_debug_literal( " n_gdi_icon_resource_load() : %s ", gdi->icon ); }
			}

			if ( is_error )
			{
				is_error = n_curico_extract( gdi->icon, &icon, gdi->icon_rsrc, gdi->icon_bpp, &gdi->icon_loaded_bpp, &gdi->icon_loaded_size );
//if ( is_error == n_posix_false ) { n_posix_debug_literal( " n_curico_extract() : %s ", gdi->icon ); }
			}

			if ( ( is_error )&&( is_lnk == n_posix_false ) )
			{
				n_gdi_icon_extract( &icon, gdi->icon, gdi->icon_index );
//if ( is_error == n_posix_false ) { n_posix_debug_literal( " n_gdi_icon_extract() : %s ", gdi->icon ); }
			}
//if ( n_posix_stat_is_dir( gdi->icon ) ) { n_bmp_save_literal( &icon, "ret.bmp" ); }
		}

//if (is_image){}

		if ( resize_needed )
		{
			n_posix_bool stretch_onoff = ( gdi->icon_style & N_GDI_ICON_STRETCH );
			n_win_icon_bmp_resize( &icon, gdi->icon_sx, gdi->icon_sy, gdi->icon_rsrc, gdi->icon_color_bg, stretch_onoff, is_image );
//n_bmp_save_literal( &icon, "0.bmp" );
		} else {
			n_win_icon_resizer( &icon, gdi->icon_sx, gdi->icon_sy, gdi->icon_color_bg );
//n_bmp_save_literal( &icon, "1.bmp" );
		}

	}

/*
	{ // Debug Frame
		u32 c = n_bmp_black + 1;
		u32 color[ 8 ] = { c,c,c,c, c,c,c,c };
		n_gdi_frame_rectframe( &icon, gdi->scale, color );
	} // Debug Frame
*/


//if ( n_posix_stat_is_dir( gdi->icon ) ) { n_bmp_save_literal( &icon, "ret.bmp" ); }

	// [!] : delayed drawing
	n_win_icon_linkarrow_draw( &icon, NULL, N_BMP_SX( &icon ), is_lnk );


	n_gdi_bmp_effect_icon( gdi, bmp, &icon );

//n_posix_char *name = n_string_path_name_new( gdi->icon );
//if ( n_string_is_same_literal( "shell32.dll", name ) ) { n_bmp_save_literal( bmp, "bmp.bmp" ); }
//n_string_path_free( name );

//if ( n_posix_stat_is_dir( gdi->icon ) ) { n_bmp_save_literal( &icon, "ret.bmp" ); }


	n_bmp_free_fast( &icon );


	return;
}


#endif // _H_NONNON_WIN32_GDI_ICON

