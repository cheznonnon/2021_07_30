// Nonnon COM : IOleContainer
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Template File : copy and modify if needed




#ifndef _H_NONNON_WIN32_COM_IOLECONTAINER
#define _H_NONNON_WIN32_COM_IOLECONTAINER




// [Patch]


#define ITargetContainer IUnknown


HRESULT __stdcall
n_ITargetContainer_IUnknown_QueryInterface( IOleContainer *_this, REFIID iid, void **ppvObject )
{
n_com_debug_a( "n_ITargetContainer_IUnknown_QueryInterface" );


	n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID t = n_com_guid( n_guid_IID_ITargetContainer );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &t ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;

	}


	return E_NOINTERFACE;
}


HRESULT __stdcall
n_ITargetContainer_GetFrameUrl( void *_this, LPWSTR *ppszFrameSrc )
{
n_com_debug_a( "ITargetContainer_GetFrameUrl" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_ITargetContainer_GetFramesContainer( void *_this, IOleContainer **ppContainer )
{
n_com_debug_a( "ITargetContainer_GetFramesContainer" );

	return E_NOTIMPL;
}


const void *n_ITargetContainer_Vtbl[] = {

	n_ITargetContainer_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_ITargetContainer_GetFrameUrl,
	n_ITargetContainer_GetFramesContainer,

};


static ITargetContainer n_ITargetContainer_instance = { (void*) n_ITargetContainer_Vtbl };





HRESULT __stdcall
n_IOleContainer_IUnknown_QueryInterface( IOleContainer *_this, REFIID iid, void **ppvObject )
{
n_com_debug_a( "n_IOleContainer_IUnknown_QueryInterface" );


	// [Mechanism]
	//
	//	{7847EC01-2BEC-11D0-82B4-00A0C90C29C5} : ITargetContainer

	//n_com_debug_IUnknown_QueryInterface( _this, iid, ppvObject );


	if ( ppvObject == NULL ) { return E_POINTER; } else { (*ppvObject) = NULL; }


	GUID u = n_com_guid( n_guid_IID_IUnknown );
	GUID o = n_com_guid( n_guid_IID_IOleContainer );
	GUID t = n_com_guid( n_guid_IID_ITargetContainer );


	if (
		( IsEqualGUID( iid, &u ) )
		||
		( IsEqualGUID( iid, &o ) )
	)
	{

		(*ppvObject) = _this;

		return S_OK;

	} else
	if ( IsEqualGUID( iid, &t ) )
	{

		(*ppvObject) = (void*) &n_ITargetContainer_instance;

		return S_OK;

	}


	return E_NOINTERFACE;
}




#define POLESTR void*
HRESULT __stdcall
n_IOleContainer_ParseDisplayName
(
	IOleContainer  *_this,
	IBindCtx       *pbc,
	POLESTR         pszDisplayName,
	ULONG          *pchEaten,
	IMoniker      **ppmkOut
)
{
n_com_debug_a( "IOleContainer_ParseDisplayName" );

	return MK_E_NOOBJECT;
}

HRESULT __stdcall
n_IOleContainer_EnumObjects( IOleContainer *_this, DWORD grfFlags, IEnumUnknown **ppenum )
{
n_com_debug_a( "IOleContainer_EnumObjects" );

	return E_NOTIMPL;
}

HRESULT __stdcall
n_IOleContainer_LockContainer( IOleContainer *_this, BOOL fLock )
{
n_com_debug_a( "IOleContainer_LockContainer" );

	return S_OK;
}




const void *n_IOleContainer_Vtbl[] = {

	n_IOleContainer_IUnknown_QueryInterface,
	n_com_IUnknown_AddRef,
	n_com_IUnknown_Release,

	n_IOleContainer_ParseDisplayName,
	n_IOleContainer_EnumObjects,
	n_IOleContainer_LockContainer

};


IOleContainer n_IOleContainer_instance = { (void*) n_IOleContainer_Vtbl };




#endif // _H_NONNON_WIN32_COM_IOLECONTAINER

