// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
void
n_oc_item_scroll_callback( void *data )
{
//n_win_debug_count( game.hwnd );

	extern void n_oc_event_on_redraw( void );
	n_oc_event_on_redraw();

	// [Needed] : force redraw
	n_game_on_paint();


	return;
}

void
n_oc_item_scroll_restore( n_oc_item *p )
{

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		oc.view_scroll_restore = n_oc_item_scroll2orangecat( p, oc.scrollbar.unit_pos * p->cell_sx );
	} else {
		oc.view_scroll_restore = n_oc_item_scroll2orangecat( p, oc.scrollbar.unit_pos * p->cell_sy );
	}

	return;
}

void
n_oc_item_scroll_restore_back( n_oc_item *p )
{

	if ( oc.scrollbar.layout == N_WIN_SCROLLBAR_LAYOUT_HORIZONTAL )
	{
		oc.scrollbar.pixel_pos = n_oc_orangecat2scroll( oc.view_scroll_restore, p->sx );
	} else {
		oc.scrollbar.pixel_pos = n_oc_orangecat2scroll( oc.view_scroll_restore, p->sy );
	}

	return;
}

void
n_oc_item_scroll_fontsize_redraw( n_oc_item *p )
{

	n_oc_item_patch_hover_on( p );

	n_oc_path_style_init ( &path );
	n_oc_path_on_resize  ( &path );
	n_oc_path_cache_reset( &path );

	n_oc_item_view_set( p );

	if ( oc.global_thread_onoff )
	{
		n_oc_item_preload_thread_go( N_ORANGECAT_INTERVAL_INIT );
	} else {
		n_oc_item_preload( p, N_ORANGECAT_INTERVAL_INIT, n_false );
	}

	n_oc_item_patch_focus_on( p, n_true );

	n_oc_event_redraw();


	return;
}

void
n_oc_item_scroll_fontsize( n_oc_item *p, int delta )
{

	if ( delta == 0 ) { return; }

	if ( delta > 0 ) { delta = 1; } else if ( delta < 0 ) { delta = -1; }


	if ( n_oc_font_is_minus )
	{
		n_oc_font_size += delta;
		//if ( n_oc_font_size >= 0 ) { n_oc_font_size = -1; }
	} else {
		n_oc_font_size -= delta;
		//if ( n_oc_font_size <= 0 ) { n_oc_font_size =  1; }
	}


	n_oc_item_scroll_fontsize_redraw( p );


//n_game_hwndprintf_literal( " %d ", n_oc_font_size );
	return;
}

void
n_oc_item_scroll_gallery( n_oc_item *p, int delta )
{

	if ( n_oc_item_error( p ) ) { return; }

	if ( delta == 0 ) { return; }


	{

		s32 step = oc.view_gallery_step; if ( delta > 0 ) { step *= -1; }
		s32 size = n_posix_max_s32( 32, oc.view_gallery_size + step );

		if ( oc.view_gallery_size != size )
		{
			n_oc_item_gallery_set( p, size );
		}

	}

//n_game_hwndprintf_literal( " %d ", oc.view_gallery_size );


	return;
}

void
n_oc_item_scroll_on_keydown( n_oc_item *p )
{

	if ( n_oc_item_error( p ) ) { return; }


	const int vk_up   = VK_PRIOR;
	const int vk_down = VK_NEXT;


	int delta = 0;

	if ( n_win_is_input( VK_CONTROL ) )
	{

		if ( n_win_is_input( vk_up   ) ) { delta = -1; }
		if ( n_win_is_input( vk_down ) ) { delta =  1; }

		if ( delta )
		{
			n_posix_sleep( N_ORANGECAT_INTERVAL_BASE );
			n_oc_item_scroll_gallery( p, delta );
		}

	} else
	if ( n_win_is_input( VK_SHIFT ) )
	{

		if ( n_win_is_input( vk_up   ) ) { delta = -1; }
		if ( n_win_is_input( vk_down ) ) { delta =  1; }

		n_oc_item_scroll_fontsize( p, delta );

	} else {

		if ( n_win_is_input( vk_up   ) ) { delta = oc.scrollbar.pixel_page * -1; }
		if ( n_win_is_input( vk_down ) ) { delta = oc.scrollbar.pixel_page *  1; }

		if ( ( delta )&&( p->count ) )
		{

			if ( 1 == n_oc_item_multifocus_count( p ) )
			{

				n_bmp_fade_redraw( &p->fade[ n_oc_item_multifocus_single( p ) ] );


				int cur = n_oc_item_multifocus_single( p );

				if ( delta < 0 )
				{
					cur -= p->scroll_item_per_page;
				} else {
					cur += p->scroll_item_per_page;
				}


				while( 1 )
				{
					if ( cur > 0 ) { break; }
					cur += p->scroll_item_per_line;
				}

				while( 1 )
				{
					if ( cur < p->count ) { break; }
					cur -= p->scroll_item_per_line;
				}


				n_oc_item_multifocus_off( p );
				p->multifocus[ cur ] = n_true;

			}

			n_win_scrollbar_scroll_pixel( &oc.scrollbar, delta, N_WIN_SCROLLBAR_SCROLL_AUTO );
			n_posix_sleep( N_ORANGECAT_INTERVAL_PBAR );
			n_oc_event_redraw_fast();
		}

	}


	return;
}


