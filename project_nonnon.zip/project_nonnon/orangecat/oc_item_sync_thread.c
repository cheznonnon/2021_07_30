// OrangeCat
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




n_thread_return
n_oc_sync_thread( n_thread_argument arg )
{

	if ( item.load_count == item.count ) { return 0; }


	s32 prv_cursor_x = -1;
	s32 prv_cursor_y = -1;

	n_win_cursor_position_relative( game.hwnd, &prv_cursor_x, &prv_cursor_y );


	u32 timer = n_posix_tickcount();


	s32 i; n_oc_item_scan_index( &item, &i, NULL, n_true );
	while( 1 )
	{

		if ( oc.scrollbar.drag_onoff ) { break; }
		if (  item.drag2select_onoff ) { break; }


		// [!] : trade-off : large value makes faster but UI is less responsive

		u32 msec;

		s32 cur_cursor_x, cur_cursor_y;
		n_win_cursor_position_relative( game.hwnd, &cur_cursor_x, &cur_cursor_y );

		if (
			( oc.view_hover == N_ORANGECAT_VIEW_HOVER_NONE )
			||
			( ( prv_cursor_x == cur_cursor_x )&&( prv_cursor_y == cur_cursor_y ) )
		)
		{
			msec = 50;
		} else {
			msec =  1;
		}

		prv_cursor_x = cur_cursor_x;
		prv_cursor_y = cur_cursor_y;

		if ( n_game_timer( &timer, msec ) ) { break; }


		if ( i >= item.count ) { i = 0; }

		n_oc_item_sync_image( &item, i, 0, n_false, n_false );

		i++;


		if ( item.load_count == item.count ) { break; }


		if ( n_win_is_input( VK_RBUTTON ) )
		//if ( n_game_click_single( &oc.singleclick_r ) )
		{

			n_posix_sleep( N_ORANGECAT_INTERVAL_BASE / 4 );

			if ( oc.view == N_ORANGECAT_VIEW_FILE )
			{
				n_oc_event_viewchange();
			} else
			if ( oc.view == N_ORANGECAT_VIEW_INFO )
			{
				extern n_bool n_oc_info_input_is_hovered( n_oc_info* );
				if ( n_false == n_oc_info_input_is_hovered( &info ) )
				{
					n_oc_event_viewchange();
				}
			}

			break;
		}


		if ( item.drag == N_ORANGECAT_DRAG_UNKNOWN )
		{

			if ( oc.is_internal_dnd )
			{
				if ( item.drag2select_onoff == n_false )
				{
					oc.view_is_key_operation = oc.view_is_key_operation_fade_out = n_false;
					n_oc_item_drag2select_init( &item );
				} else {
					n_oc_item_drag2select_loop( &item );
				}
			}

		}

	}


	return 0;
}

void
n_oc_sync_thread_go( void )
{

	if (
(0)&&
		( oc.global_thread_onoff )
		&&
		( n_thread_onoff() )
	)
	{

		n_bool p_multithread = n_bmp_is_multithread;
		n_bmp_is_multithread = n_true;

		n_bool p_trans = n_bmp_transparent_onoff_default;
		n_bmp_transparent_onoff_default = n_true;


	 	u32 cores = n_thread_core_count;

		n_thread *h = n_memory_new( cores * sizeof( n_thread ) );


		u32 i = 0;
		while( 1 )
		{

			h[ i ] = n_thread_init( n_oc_sync_thread, NULL );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_wait( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}

		i = 0;
		while( 1 )
		{

			n_thread_exit( h[ i ] );

			i++;
			if ( i >= cores ) { break; }
		}


		n_memory_free( h );


		n_bmp_is_multithread = p_multithread;

		n_bmp_transparent_onoff_default = p_trans;


		n_oc_event_redraw_fast();

	} else {

		n_oc_sync_thread( NULL );

		n_oc_event_redraw_fast();

	}


	return;
}

