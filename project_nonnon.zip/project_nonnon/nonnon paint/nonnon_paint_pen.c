// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
double
n_paint_pen_edge( s32 x, s32 y, s32 r, double coeff, double blend )
{

	const double xx = x * x;
	const double yy = y * y;
	const double rr = r * r;

	const double dx = xx / rr;
	const double dy = yy / rr;

	const double normalized_map = 1.0 - ( dx + dy );

	const double p = pow( normalized_map, edge * 0.25 );


	return n_posix_min_double( coeff, coeff * p ) * blend;
}

double
n_paint_pen_air( s32 x, s32 y, s32 radius, double coeff, double blend )
{

	if ( 0 == n_random_range( air ) )
	{
		coeff = n_paint_pen_edge( x,y, radius, coeff, blend );
		coeff = coeff * ( 1.0 / 7.5 );
	} else {
		coeff = 0;
	}


	return coeff;
}

// internal
int
n_paint_average( u32 color )
{

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );


	return ( a + r + g + b ) / 4;
}

// internal
void
n_paint_pen_engine( s32 fx, s32 fy, double blend )
{

	if ( blend == 0.0 ) { return; }


	int radius = n_paint_pen_radius;
	u32 color  = n_paint_pen_color;

	if ( n_paint_quick_eraser ) { color = n_paint_tool_color_transparent_get(); }


	// [Patch] : size will be smaller when smooth is ON

	if ( blend < 1.0 ) { radius++; }

//n_win_hwndprintf_literal( hwnd_main, "%d %x %f", radius, color, blend );

	s32 x = -radius;
	s32 y = -radius;
	while( 1 )
	{

		double coeff;
		if (
			( radius == 0 )
			||
			( n_bmp_ellipse_detect_coeff( x,y, radius,radius, &coeff ) )
		)
		{

			s32 tx = fx + x;
			s32 ty = fy + y;


			// [!] : don't use -1 == 0xffffffff == n_bmp_argb( 255,255,255,255 )

			u32 color_f = color + 1;
			u32 color_t = color;


			if ( mix == 100 )
			{

				n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color  , &color_f, &color_t, 0.0 );
				n_paint_grabber_pixel_set(                   tx,ty, color_f, color_t                 );

			} else {

				// [!] : multi-layer eraser

				if (
					( n_paint_grabber_wholegrb_onoff )
					&&
					( n_paint_layer_multiselect )
					&&
					( color == n_bmp_white_invisible )
				)
				{
//color_t = n_bmp_rgb( 0,200,255 );

					s32 gx,gy; n_paint_grabber_system_get( &gx,&gy, NULL,NULL, NULL,NULL );

					s32 orig_x = tx;
					s32 orig_y = ty;
					s32 grab_x = tx - gx;
					s32 grab_y = ty - gy;

					int i = 0;
					while( 1 )
					{

						n_bmp *bmp_data = &n_paint_layer_data[ i ].bmp_data;
						n_bmp *bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

						u32 c1;
						n_bmp_ptr_get( bmp_data, orig_x,orig_y, &c1 );

						u32 c2;
						n_bmp_ptr_get( bmp_grab, grab_x,grab_y, &c2 );

						double d;
						if ( air )
						{
							d = n_paint_pen_air ( x,y, radius, coeff, blend );
						} else {
							d = n_paint_pen_edge( x,y, radius, coeff, blend );
						}

						c1 = n_bmp_blend_pixel( c2, c1, d );
						n_bmp_ptr_set( bmp_grab, grab_x,grab_y,  c1 );

						i++;
						if ( i >= n_paint_layer_count ) { break; }
					}

				} else {

					if ( air )
					{
						n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color, &color_f, &color_t, 0.25 );
						coeff = n_paint_pen_air ( x,y, radius, coeff, blend );
					} else {
						n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color, &color_f, &color_t, 0.00 );
						coeff = n_paint_pen_edge( x,y, radius, coeff, blend );
					}

					color_t = n_bmp_blend_pixel( color_f, color_t, coeff );

					n_paint_grabber_pixel_set( tx,ty, color_f, color_t );

				}

			}

		}


		x++;
		if ( x > radius )
		{

			x = -radius;

			y++;
			if ( y > radius ) { break; }
		}

	}


	return;
}

// internal
void
n_paint_pen_refresh( s32 fx, s32 fy, s32 tx, s32 ty )
{

//n_paint_refresh_all(); return;


	// [Needed] : +1

	s32 redraw_fx = n_posix_min_s32( fx, tx ) - n_paint_pen_radius;
	s32 redraw_fy = n_posix_min_s32( fy, ty ) - n_paint_pen_radius;
	s32 redraw_tx = n_posix_max_s32( fx, tx ) + n_paint_pen_radius + 1;
	s32 redraw_ty = n_posix_max_s32( fy, ty ) + n_paint_pen_radius + 1;

	n_paint_refresh
	(
		NULL,
		redraw_fx, redraw_fy,
		redraw_tx, redraw_ty,
		N_PAINT_REFRESH_CLIENT,
		N_PAINT_REFRESH_ID_PEN
	);


	return;
}

#define N_PAINT_PEN_START 0
#define N_PAINT_PEN_LOOP  1
#define N_PAINT_PEN_STOP  2

#define n_paint_pen_start() n_paint_pen( N_PAINT_PEN_START )
#define n_paint_pen_loop()  n_paint_pen( N_PAINT_PEN_LOOP  )
#define n_paint_pen_stop()  n_paint_pen( N_PAINT_PEN_STOP  )

void
n_paint_pen( int mode )
{

	static s32 px;
	static s32 py;


	s32 fx,fy, tx,ty;

	n_paint_canvaspos( &tx, &ty );

	if ( mode == N_PAINT_PEN_START )
	{

		n_paint_pen_start_x = px = fx = tx;
		n_paint_pen_start_y = py = fy = ty;

	} else {

		if ( mode == N_PAINT_PEN_STOP )
		{
			if ( ( n_paint_pen_start_x == tx )&&( n_paint_pen_start_y == ty ) ) { return; }
		}

		fx = px;
		fy = py;

	}


	if (
		( mode == N_PAINT_PEN_LOOP )
		&&
		( n_paint_pen_blend != 1.0 )
	)
	{

		// Anti-Shake

		if ( antishake )
		{

			const int threshold = 2;

			if ( threshold <= abs( fx - tx ) ) { tx = ( fx + tx ) / threshold; }
			if ( threshold <= abs( fy - ty ) ) { ty = ( fy + ty ) / threshold; }

		}


		// [!] : nothing to do

		if ( ( fx == tx )&&( fy == ty ) ) { return; }

	}


#ifdef _H_NONNON_WIN32_WIN_WINTAB

//n_win_hwndprintf_literal( hwnd_main, "%d / %d", n_wintab_pressure_get( &n_paint_wintab ), n_wintab_pressure_max( &n_paint_wintab ) );
	if ( ( n_paint_wintab_onoff )&&( n_wintab_is_pressed( &n_paint_wintab ) ) )
	{
		double max = n_wintab_pressure_max( &n_paint_wintab );
		double cur = n_wintab_pressure_get( &n_paint_wintab );

		//double pen = (double) pensize * ( cur / max );
		//n_paint_pen_radius = pen / 2;

		n_paint_pen_blend = (double) ( mix * 0.01 ) * ( cur / max );
	}
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


	if ( n_paint_pen_blend == 1.0 )
	{
		n_bmp_pen_bresenham( fx,fy, tx,ty, n_paint_pen_blend, n_paint_pen_engine );
	} else {
		n_bmp_pen_wu       ( fx,fy, tx,ty, n_paint_pen_blend, n_paint_pen_engine );
	}

	px = tx;
	py = ty;


	n_paint_status();


	n_paint_pen_refresh( fx,fy, tx,ty );


	return;
}

void
n_paint_pen_on_lbuttondown( HWND hwnd )
{

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start == n_false )
		{

			if ( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) ) { return; }
			if ( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) ) { return; }


			n_paint_pen_start = n_true;


			SetCapture( hwnd );


			// [!] : pre-calculate

			n_paint_pen_radius = pensize;
			n_paint_pen_color  = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );
			n_paint_pen_blend  = (double) mix * 0.01;

#ifdef _H_NONNON_WIN32_WIN_WINTAB
			if ( ( n_paint_wintab_onoff )&&( n_wintab_is_eraser( &n_paint_wintab ) ) )
			{

				n_paint_pen_color = n_paint_tool_color_transparent_get();

				n_win_cursor_add_literal( NULL, "NONNON_PAINT_ERASER" );

			} else
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB
			{

				if ( n_false == n_paint_quick_eraser )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN_ON" );
				}

			}


			// [!] : the first input

			n_paint_pen_start();

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		n_paint_grabber_fill();

	}


	n_paint_colorhistory_add( n_paint_pen_color );


	return;
}

void
n_paint_pen_on_mousemove( HWND hwnd )
{

	n_paint_status();

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start )
		{

			if ( n_win_is_input( N_PAINT_PEN_STRAIGHTLINE_VK ) )
			{
				if ( n_paint_pen_straight_line == n_false )
				{
					n_paint_pen_start();
				}
				n_paint_pen_straight_line = n_true;
				n_paint_refresh_client();
			} else {
				n_paint_pen_loop();
			}

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		//

	}


	return;
}

void
n_paint_pen_on_lbuttonup( HWND hwnd )
{

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start )
		{

			n_paint_pen_stop();


			ReleaseCapture();


#ifdef _H_NONNON_WIN32_WIN_WINTAB
			if ( ( n_paint_wintab_onoff )&&( n_wintab_is_eraser( &n_paint_wintab ) ) )
			{

				n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN" );

			} else
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB
			{

				if ( n_false == n_paint_quick_eraser )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN" );
				}

			}


			n_paint_pen_start = n_false;

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		//

	}


	return;
}

void
n_paint_pen_cursor_move( s32 delta_x, s32 delta_y )
{

	POINT p; GetCursorPos( &p );
	SetCursorPos( p.x + delta_x, p.y + delta_y );

	return;
}

void
n_paint_pen_key2cursor( void )
{

	s32 step = 1;

	if ( n_paint_is_zoom_in( zoom ) ) { step = n_paint_zoom_get( zoom ); }

	s32 x = 0;
	s32 y = 0;

	if ( n_win_is_input( VK_UP    ) ) { y -= step; }
	if ( n_win_is_input( VK_DOWN  ) ) { y += step; }
	if ( n_win_is_input( VK_LEFT  ) ) { x -= step; }
	if ( n_win_is_input( VK_RIGHT ) ) { x += step; }

	n_paint_pen_cursor_move( x, y );


	return;
}

n_bool
n_paint_is_clientarea( void )
{

	POINT p; GetCursorPos( &p );

	ScreenToClient( hwnd_main, &p );

	RECT r; GetClientRect( hwnd_main, &r );


	return(
		( p.x >= 0 )&&( p.y >= 0 )
		&&
		( p.x < r.right )&&( p.y < r.bottom )
	);
}

int
n_paint_pen_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//return 0;

	if ( n_paint_on_setcursor_condition() )
	{
		if ( n_paint_pen_start == n_false )
		{
			return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
		}
	}


	// [!] : grabber is ON

	if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
	{
		if ( n_paint_is_shiftzoom )
		{
			n_paint_is_shiftzoom = n_false;
			n_paint_refresh_client();
		}

		return 0;
	}


	if ( n_paint_layer_rename_onoff ) { return 0; }


	switch( msg ) {


	case WM_KEYDOWN :

		if ( n_paint_layer_onoff )
		{
			int y = n_paint_layer_txtbox.select_cch_y;
			if ( n_false == n_paint_layer_data[ y ].visible ) { break; }
		}

		if ( n_win_is_hovered( hwnd_layr ) ) { break; }

		if ( wparam == VK_SHIFT )
		{
			if (
				( n_false == n_win_is_input( VK_CONTROL ) )
				&&
				( n_paint_pen_start    == n_false )
				&&
				( n_paint_is_shiftzoom == n_false )
			)
			{
				n_paint_is_shiftzoom = n_true;
				n_paint_refresh_client();

				n_win_cursor_add( NULL, IDC_ARROW );
				n_win_cursor_add( hwnd, IDC_ARROW );
			}
		}

	break;

	case WM_KEYUP :

		if ( wparam == N_PAINT_PEN_STRAIGHTLINE_VK )
		{
			if ( n_paint_pen_start )
			{
				n_paint_pen_on_lbuttonup( hwnd );

				if ( n_paint_pen_straight_line )
				{
					n_paint_pen_straight_line = n_false;
					n_paint_refresh_client();
				}

				n_paint_pen_on_lbuttondown( hwnd );
			}
		} else
		if ( wparam == VK_SHIFT )
		{
			if ( n_false == n_win_is_input( VK_LBUTTON ) )
			{
				n_paint_is_shiftzoom = n_false;

				// [Needed] : 64-bit : High-DPI
				n_bmp_flush( &n_paint_bmp_dbuf, N_PAINT_CANVAS_COLOR );

				n_paint_refresh_client();

				if ( n_paint_is_clientarea() )
				{
					n_paint_pen_cursor_default( NULL );
					n_paint_pen_cursor_default( hwnd );
				} else {
					n_win_cursor_add( NULL, IDC_ARROW );
					n_paint_pen_cursor_default( hwnd );
				}
			}
		}

	break;


	case WM_LBUTTONDOWN :

		{
			s32 x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

			if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
			{
				break;
			}
		}


		if ( wparam & MK_SHIFT )
		{
			if ( ( n_paint_pen_start == n_false )&&( n_paint_is_shiftzoom == n_false ) )
			{
				n_paint_is_shiftzoom = n_true;
				n_paint_refresh_client();
			}
		} else {
			n_paint_pen_on_lbuttondown( hwnd );
		}

	break;

	case WM_MOUSEMOVE :
//n_win_hwndprintf_literal( hwnd_main, " %d ", n_win_is_input( VK_CONTROL ) );

#ifdef _H_NONNON_WIN32_WIN_WINTAB
		if ( n_paint_wintab_onoff )
		{
			if ( n_wintab_is_eraser( &n_paint_wintab ) )
			{
				n_win_cursor_add_literal( hwnd, "NONNON_PAINT_ERASER" );
			} else {
				//
			}
		}
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

		n_paint_pen_on_mousemove( hwnd );

	break;

	case WM_LBUTTONUP :

		if ( n_paint_is_shiftzoom )
		{

			if (
				( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
				||
				( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			)
			{
				break;
			}

			s32 cur; n_win_cursor_position_relative( hwnd_main, NULL, &cur );
			s32 pos = 0;
			if ( cur < ( nwin_main.csy / 2 ) )
			{
				pos =  1;
			} else
			if ( cur > ( nwin_main.csy / 2 ) )
			{
				pos = -1;
			} 
			n_paint_tool_scrollbar_updown( &n_paint_tool_hscr[ 4 ], pos );

		} else {

			n_paint_pen_on_lbuttonup( hwnd );

			if ( n_paint_pen_straight_line )
			{
				n_paint_pen_straight_line = n_false;
				n_paint_refresh_client();
			}

		}

	break;


	case WM_RBUTTONDOWN :
//n_win_debug_count( hwnd ); break;

		if ( n_paint_is_shiftzoom ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if (
			( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			||
			( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		)
		{
			//
		} else {
			n_paint_colorpicker();
		}

	break;


	} // switch


	return n_false;
}

