


//#define UNICODE




#include "../../nonnon/win32/win.c"

#include "../../nonnon/project/macro.c"




LRESULT CALLBACK
WndProc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{

	switch( msg ) {


	case WM_CONVERTREQUESTEX :
n_win_hwndprintf_literal( hwnd, " WM_CONVERTREQUESTEX " );
	break;

	case WM_IME_STARTCOMPOSITION :
n_win_hwndprintf_literal( hwnd, " WM_IME_STARTCOMPOSITION " );
	break;

	case WM_IME_ENDCOMPOSITION :
n_win_hwndprintf_literal( hwnd, " WM_IME_ENDCOMPOSITION " );
	break;

	case WM_IME_COMPOSITION :
n_win_hwndprintf_literal( hwnd, " WM_IME_COMPOSITION " );
	break;

	case WM_IME_SETCONTEXT :
n_win_hwndprintf_literal( hwnd, " WM_IME_SETCONTEXT " );
	break;

	case WM_IME_NOTIFY :
n_win_hwndprintf_literal( hwnd, " WM_IME_NOTIFY : %d ", wparam );

		// [!] : launched : IMN_OPENSTATUSWINDOW 2
		// [!] : on/off   : IMN_SETOPENSTATUS    8

	break;

	case WM_IME_CONTROL :
n_win_hwndprintf_literal( hwnd, " WM_IME_CONTROL " );
	break;

	case WM_IME_COMPOSITIONFULL :
n_win_hwndprintf_literal( hwnd, " WM_IME_COMPOSITIONFULL " );
	break;

	case WM_IME_SELECT :
n_win_hwndprintf_literal( hwnd, " WM_IME_SELECT " );
	break;

	case WM_IME_CHAR :
n_win_hwndprintf_literal( hwnd, " WM_IME_CHAR " );
	break;

	case WM_IME_KEYDOWN :
n_win_hwndprintf_literal( hwnd, " WM_IME_KEYDOWN " );
	break;

	case WM_IME_KEYUP :
n_win_hwndprintf_literal( hwnd, " WM_IME_KEYUP " );
	break;

	case WM_IME_REQUEST :
n_win_hwndprintf_literal( hwnd, " WM_IME_REQUEST " );
	break;


	case WM_CREATE :

		n_win_init_literal( hwnd, "", "", "" );

		n_win_style_new( hwnd, WS_OVERLAPPEDWINDOW );


		n_win_set( hwnd, NULL, 512,0, N_WIN_SET_CENTERING );


		ShowWindow( hwnd, SW_NORMAL );

	break;


	case WM_CLOSE :

		ShowWindow( hwnd, SW_HIDE );

		DestroyWindow( hwnd );

	break;

	case WM_DESTROY :

		PostQuitMessage( 0 );

	break;


	} // switch


	return DefWindowProc( hwnd, msg, wparam, lparam );
}

int WINAPI
WinMain( HINSTANCE hinst, HINSTANCE prv_hinst, LPSTR cmd, int show )
{
	return n_win_main( NULL, WndProc );
}

