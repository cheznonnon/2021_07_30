



#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>


#include <windows.h>
#include <wininet.h>




#define mb( s ) MessageBox( NULL, s, "", 0 )




int
main( int argc, char *argv[] )
{

	long tmp;
	char str[ N_PATH_MAX ];
	char dir[ N_PATH_MAX ];


	HINTERNET       inet, session, folder;
	WIN32_FIND_DATA f;


	inet = InternetOpen
	(
		"NONNON TEST",
		INTERNET_OPEN_TYPE_DIRECT,
		NULL,NULL,
		0
	);

	if ( inet == NULL ) { mb( "inet" ); }


	session = InternetConnect
	(
		inet,
		"host",
		INTERNET_DEFAULT_FTP_PORT,
		"name",
		"password",
		INTERNET_SERVICE_FTP,
		0,0
	);

	if ( session == NULL ) { mb( "session" ); }


	tmp = MAX_PATH;
	tmp = FtpGetCurrentDirectory( session, dir, &tmp );

	//n_debug_error();

	mb( dir );


	ZeroMemory( &f, sizeof(WIN32_FIND_DATA) );

	folder = FtpFindFirstFile
	(
		session,
		"*.*",
		&f,
		INTERNET_FLAG_NO_CACHE_WRITE,
		0
	);

	if (
		( folder != NULL )
		&&
		( ERROR_NO_MORE_FILES != GetLastError() )
	)
	{

		while( 1 )
		{

			mb( f.cFileName );

			tmp = InternetFindNextFile( folder, &f );

			if ( tmp == FALSE ) { break; }
		}

	}


	InternetCloseHandle( folder );

	InternetCloseHandle( session );

	InternetCloseHandle( inet );


	return 0;
}

